<?php
session_start();  // Start a session
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "aaramb";

// Create connection
$conn = new mysqli($servername, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST["submit"])) {
    $Email = $_POST['Email'];
    $Password = $_POST['Password'];
    
    $sql = "SELECT * FROM reg WHERE Email = '$Email' AND Password = '$Password'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
    
    if ($result->num_rows > 0) {
        // Store user details in session variables
        $_SESSION['CollegeName'] = $row['CollegeName'];
        $_SESSION['CollegeCode'] = $row['CollegeCode'];
        $_SESSION['Password'] = $row['Password']; 
        $_SESSION['Email'] = $row['Email'];  // Assuming you have an email field in your database
        $_SESSION['Location'] = $row['Location'];  // Assuming you have a phone field in your database
        header("Location: index.php"); // Redirect to profile page
        exit();
    } else {
        echo '<script>
            window.location.href = "login.php";
            alert("Login failed. Invalid Username or Password");
        </script>';
    }
}

$conn->close();
?>
